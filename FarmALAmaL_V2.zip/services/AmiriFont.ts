// This file is intentionally left empty.
// The font is now loaded dynamically in Sales.tsx to prevent parsing errors and improve performance.
export const amiriFont = '';
